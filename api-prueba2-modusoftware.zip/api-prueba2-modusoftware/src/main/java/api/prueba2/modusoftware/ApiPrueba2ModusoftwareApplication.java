package api.prueba2.modusoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPrueba2ModusoftwareApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPrueba2ModusoftwareApplication.class, args);
	}

}
