package api.prueba2.modusoftware.models.dao;

import org.springframework.data.repository.CrudRepository;

import api.prueba2.modusoftware.models.entities.Array;

public interface IArrayDao extends CrudRepository<Array,Long> {
	
	

}
