package api.prueba2.modusoftware.models.services;

import api.prueba2.modusoftware.models.entities.Array;


public interface IArrayService {
	
	public Array findById(Long id);

}
