package com.webservice.uts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPrueba2ModusoftwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
